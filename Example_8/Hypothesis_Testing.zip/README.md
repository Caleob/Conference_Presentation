# Example 8: Statistical Hypothesis Testing Calculator Suite

## What is this app?
This is a comprehensive, college-ready inferential statistics tool. It allows students and educators to run 4 major hypothesis tests: Chi-Square Test for Variance ($\sigma^2$), One-Sample T-Test for Mean ($\mu$), Z-Test for Mean ($\mu$), and Z-Test for Proportion ($p$). It dynamically renders the corresponding probability distribution curve on an HTML5 canvas, shades critical rejection regions ($\alpha$), plots the calculated test statistic, and computes exact p-values in real time.

## How to use it in a virtual K-12 or AP Statistics classroom
* **Visualizing the Rejection Region:** Type in sample data and critical values. Watch the distribution curve dynamically shade the alpha rejection tails (left, right, or two-tailed).
* **Instant Decision Making:** Students immediately see whether the test statistic falls in the shaded critical zone to reject the null hypothesis ($H_0$) or fails to reject.
* **Side-by-Side Formula Verification:** Shows clean mathematical formulas with numbers plugged in alongside the live calculation.
* **Dual Architecture Comparison:** Contains two distinct folders showcasing the same app:
  - `Vanilla/`: 100% offline, zero dependencies, double-click and run anywhere.
  - `Tailwind Calculator/`: Uses modern Tailwind utility styling.

## What a non-coder learns from prompting this app
* **Frameworks vs. Vanilla:** How to choose between utility frameworks (Tailwind) and native zero-dependency code (Vanilla) depending on your school's offline and security requirements.
* **Advanced Computational Mathematics:** Prompting AI to implement continuous probability distributions and numerical calculus approximations without relying on external graphing libraries or subscriptions.
* **Building Multi-Tool Suites:** Designing unified menu navigation where multiple related tools share consistent styling, state management, and visual feedback paradigms.

# Example 7: Polar Defender (Tactical Coordinate Intercept)

## What is this app?
Polar Defender is an arcade-style radar defense game where students take on the role of an intercept defense operator. Hostile threats emerge on a circular 360-degree radar screen at specific polar coordinates $(r, \theta)$. Students must interpret the distance ($r$) and angle ($\theta$) telemetry to rotate and fire their central defense turret before threats breach perimeter shields.

## How to use it in a virtual K-12 classroom
* **Gamified Math Practice:** Turn tedious coordinate plotting into an adrenaline-fueled defense drill. Students eagerly calculate angles to protect their shields.
* **Call Sign System for Stream Privacy:** Students log in with fun tactical call signs (like VIPER, GHOST, or MATHWIZ) so you can share screens and leaderboard scores without exposing real student names.
* **Tiered Scaffolding for Differentiation:**
  - **Recruit:** 10 shields, extended target fuse, continuous angle markers.
  - **Veteran:** 7 shields, standard fuse, intermediate guidelines.
  - **Commander:** 5 shields, rapid threats, radians ($\pi/6, \pi/4\dots$), and negative radius coordinates ($(-r, \theta)$).
* **Audio Atmosphere with Total Mute Control:** Includes high-energy retro synth soundtrack and tactical sound effects, with instant one-click mute toggles for classroom harmony.

## What a non-coder learns from prompting this app
* **Arcade Gamification & "Game Feel":** You can ask AI to add game industry juice—screen shakes on explosion impacts, turret recoil kickback, particle sparks, and glowing phosphor sweep lines.
* **Media Asset Orchestration:** How to instruct AI to load local audio files gracefully, respecting browser autoplay security restrictions by unlocking audio on the initial button click.
* **Escalating Cognitive Load:** Prompting AI to introduce mathematical complexity in waves—starting with simple positive degree angles before challenging students with radians and negative radius equivalents.
